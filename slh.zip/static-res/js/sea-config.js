seajs.config({

	base:"/static-res/js/" ,
    // 设置路径，方便调用
    /*path:{
    	'jQueryv1.9.1.min':'jQueryv1.9.1.min',
        'undersocre':'underscore-min',
        'Backbone':"backbone-min"
    },*/
    alias:{
    'jquery':"/static-res/js/jQueryv1.9.1.min",
    '$':"/static-res/js/jQueryv1.9.1.min",
    'undersocre':'/static-res/js/underscore-min',
    '_':'/static-res/js/underscore-min',
    'json2':'/static-res/js/json2',
    'Backbone':"/static-res/js/backbone-min"
    }

})