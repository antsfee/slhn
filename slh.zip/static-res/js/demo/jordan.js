define('jordan',function(require,exports){

exports.chamions=function(){

	return require('pipe').hasJoined();

}

var rodman = require('rodman');
    
    exports.next3=function(){
    
    return require('rodman').hasJoined();
    
    };


});